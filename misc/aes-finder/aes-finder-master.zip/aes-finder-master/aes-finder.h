#pragma once

static void process_buffer(uint32_t &avail, uint32_t &offset, uint8_t  buffer[65536], uint64_t &addr);
