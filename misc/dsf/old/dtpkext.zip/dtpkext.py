# =====================================================================================================
# Sega Dreamcast AM2 DTPK driver data extractor v0.00 (2008-10-31) by kingshriek
# Dumps DTPK sound files used by the AM2 DTPK sound driver from an uncompressed archive.
# Version history located near end of file
# =====================================================================================================

# =====================================================================================================
import os
import sys
import mmap
from struct import *
from glob import *
# =====================================================================================================

# =====================================================================================================
def sndext(finame,outdir):
	try:
		fi = open(finame,'rb')
	except:
		return -1
	fisz  = os.path.getsize(finame)
	fimap = mmap.mmap(fi.fileno(),fisz,access=mmap.ACCESS_READ)
# -----------------------------------------------------------------------------------------------------
	fibase = os.path.basename(finame)
	idot  = -fibase[::-1].find('.')-1
	if idot:
		finoext = fibase[:idot]
	else:
		finoext = fibase
# -----------------------------------------------------------------------------------------------------
	offset = 0
	hdrmap = {'DTPK': 0}
	while offset < fisz:
		ext = finame[finame.find('.'):]
		hdr = fimap[offset:offset+4]
		if hdr in hdrmap:
			size = unpack('<I', fimap[offset+0x8:offset+0xC])[0]
			id = unpack('<I', fimap[offset+4:offset+8])[0]
			if size < 0x800000 and id < 0x100:    # Warning! May generate false positives!
				foname = '%s_%03d_%02X.%s' % (finoext, hdrmap[hdr], id, hdr)
				print '[0x%08X] %s, %d bytes' % (offset,foname,size)
				open(os.path.join(outdir,foname), 'wb').write(fimap[offset:offset+size])
				offset += size
				hdrmap[hdr] += 1
			else:
				offset += 1
		else:
			offset += 1
		offset = fimap.find('D', offset)
		if offset < 0:
			break
# -----------------------------------------------------------------------------------------------------
	fimap.close()
	fi.close()
	return
# =====================================================================================================

# =====================================================================================================
if __name__ == '__main__':
	argv = sys.argv
	argc = len(argv)
	if argc < 3:
		print 'Sega AM2 DTPK sound data extractor v0.00 by kingshriek'
		print 'Usage: python %s <filename(s)> <output directory>' % argv[0]
		sys.exit()
	outdir = argv[-1]
	if not os.path.exists(outdir):
		os.mkdir(outdir)
	for arg in argv[1:-1]:
		finames = glob(arg)
		for finame in finames:
			sndext(finame,outdir)
# =====================================================================================================

# =====================================================================================================
# 08-01-31 (0.00) - Initial version.
# =====================================================================================================
