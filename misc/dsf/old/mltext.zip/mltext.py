# =====================================================================================================
# Sega Dreamcast MLT data extractor(ver 0.02 2008-10-12)  by kingshriek
# Command-line interface script to extract MLT data out of a file/archive
# Update history located near end of file
# =====================================================================================================

# =====================================================================================================
import os
import sys
import mmap
from struct import *
from glob import *
# =====================================================================================================

# =====================================================================================================
def mltext(finame,outdir):
	try:
		fi    = open(finame,'rb')
	except:
		return -1
	fisz  = os.path.getsize(finame)
	fimap = mmap.mmap(fi.fileno(),fisz,access=mmap.ACCESS_READ)
# -----------------------------------------------------------------------------------------------------
	fibase = os.path.basename(finame)
	idot  = -fibase[::-1].find('.')-1
	if idot:
		finoext = fibase[:idot]
	else:
		finoext = fibase
# -----------------------------------------------------------------------------------------------------
	offset = 0
	index = 0
	hdrlist = ('SMSB','SMPB','SOSB','SFPB','SFOB','SFPW','SMDB','SPSR')
	try:
		while offset < fisz:
			ext = finame[finame.find('.'):]
			offset = fimap.find('SMLT',offset)
			if offset < 0:
				break
			if fimap[offset+0x20:offset+0x24] not in hdrlist:
				offset += 4
				continue
			temp_offset = offset + 0x20
			nhdr = unpack('B',fimap[offset+8])[0]
			mltsize = 0x20 * (nhdr + 1)
			mltstr = ''
			for k in range(0,nhdr):
				hdr = fimap[temp_offset:temp_offset+4]
				bank = unpack('B',fimap[temp_offset+4])[0]
				addr = unpack('<i',fimap[temp_offset+0x10:temp_offset+0x14])[0]
				size = unpack('<i',fimap[temp_offset+0x14:temp_offset+0x18])[0]
				if (addr >= 0 and fimap[offset+addr:offset+addr+4] == hdr) or hdr == 'SFPW' or hdr == 'SPSR':
					mltstr += '%s%d ' % (hdr,bank)
					totalsize = addr + size
					if totalsize > mltsize:
						mltsize = totalsize
				temp_offset += 0x20	
			if mltsize > 0:
				foname = '%s_%03d.MLT' % (finoext, index)
				print '%s [0x%08X]: %d bytes - %s' % (foname,offset,mltsize,mltstr)
				fo = open(os.path.join(outdir,foname),'wb')
				fo.write(fimap[offset:offset+mltsize])
				fo.close()
				offset += mltsize
				index += 1
			else:
				offset += 4
# -----------------------------------------------------------------------------------------------------
	except:
		fimap.close()
		fi.close()
		return index
# -----------------------------------------------------------------------------------------------------
	fimap.close()
	fi.close()
	return index
# =====================================================================================================

# =====================================================================================================
if __name__ == '__main__':
	argv = sys.argv
	argc = len(argv)
	if argc < 3:
		print 'Sega Dreamcast MLT extractor v0.02 by kingshriek'
		print 'Usage: python %s <filename(s)> <output directory>' % argv[0]
		sys.exit()
	outdir = argv[-1]
	if not os.path.exists(outdir):
		os.mkdir(outdir)
	for arg in argv[1:-1]:
		finames = glob(arg)
		for finame in finames:
			ibin = mltext(finame,outdir)
			if ibin == 0:
				print '--- %s: No mlt data found' % finame
# =====================================================================================================

# =====================================================================================================
# Update history:
# 08-10-12 (0.02) - Added __name__ == '__main__' statement. Script will now create output directory
#                   if it doesn't exist.
# 08-02-17 (0.01) - Added SPSR to allowable header list. Changed output to only display non-null banks.
# 08-01-12 (0.00) - Initial version.
# =====================================================================================================
