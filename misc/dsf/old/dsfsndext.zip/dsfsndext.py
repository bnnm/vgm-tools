# =====================================================================================================
# Sega Dreamcast Manatee driver data extractor v0.01 (2008-10-20) by kingshriek
# Inspired by Sound EXT.exe tool by manakoAT.
# Dumps sound files relevant to the Dreamcast's Manatee driver from an uncompressed archive.
# This tool will only dump MLT headers and not full MLT files (use mltext for that).
# Version history located near end of file
# =====================================================================================================

# =====================================================================================================
import os
import sys
import mmap
from struct import *
from glob import *
# =====================================================================================================

# =====================================================================================================
def sndext(finame,outdir):
	try:
		fi = open(finame,'rb')
	except:
		return -1
	fisz  = os.path.getsize(finame)
	fimap = mmap.mmap(fi.fileno(),fisz,access=mmap.ACCESS_READ)
# -----------------------------------------------------------------------------------------------------
	fibase = os.path.basename(finame)
	idot  = -fibase[::-1].find('.')-1
	if idot:
		finoext = fibase[:idot]
	else:
		finoext = fibase
# -----------------------------------------------------------------------------------------------------
	offset = 0
	hdrmap = {'SMLT': 0, 'SDRV': 0, 'SMSB': 0, 'SMPB': 0, 'SOSB': 0, 'SFPB': 0, 'SFOB': 0, 'SMDB': 0}
	while offset < fisz:
		ext = finame[finame.find('.'):]
		hdr = fimap[offset:offset+4]
		if hdr in hdrmap:
			if hdr == 'SMLT':
				nhdrs = unpack('<I', fimap[offset+0x8:offset+0xC])[0]
				size = 0x20 * (nhdrs + 1)
			else:
				size = unpack('<I', fimap[offset+0x8:offset+0xC])[0]
			version = unpack('B', fimap[offset+4])[0]
			if size < 0x800000 and version < 0x10:    # Warning! May generate false positives!
				foname = '%s_%03d.%s' % (finoext, hdrmap[hdr], hdr[1:])
				print '[0x%08X] %s, %d bytes' % (offset,foname,size)
				open(os.path.join(outdir,foname), 'wb').write(fimap[offset:offset+size])
				offset += size
				hdrmap[hdr] += 1
			else:
				offset += 1
		else:
			offset += 1
		offset = fimap.find('S', offset)
		if offset < 0:
			break
# -----------------------------------------------------------------------------------------------------
	fimap.close()
	fi.close()
	return
# =====================================================================================================

# =====================================================================================================
if __name__ == '__main__':
	argv = sys.argv
	argc = len(argv)
	if argc < 3:
		print 'Sega Dreamcast Manatee sound data extractor v0.01 by kingshriek'
		print 'Usage: python %s <filename(s)> <output directory>' % argv[0]
		sys.exit()
	outdir = argv[-1]
	if not os.path.exists(outdir):
		os.mkdir(outdir)
	for arg in argv[1:-1]:
		finames = glob(arg)
		for finame in finames:
			sndext(finame,outdir)
# =====================================================================================================

#=====================================================================================================
# 08-10-20 (v0.01) - Fixed a minor bug in the filename indexing. Made the script faster.
# 08-10-12 (v0.00) - Initial release.
#=====================================================================================================
