# =====================================================================================================
# Extremely basic ssf dumper (ver 0.07 2008-05-28)  by kingshriek
# To be run alongside SSF (emulator), Yabause or any other Saturn/ST-V emulator capable of dumping sound RAM 
# Update history located near end of file
# =====================================================================================================

# =====================================================================================================
# NOTE: 
#	- This script targets the standard Sega sound driver that I expect is used in most games. Don't
#		expect it to work on everything.
#	- No optimizations are performed with regards to file size (via zero-ing out unneeded data or by ssflib/minissf). 
#             The script more or less simply does a full dump of the 512K sound memory.
# -----------------------------------------------------------------------------------------------------
# Requires:
# 	pmdump (http://www.ntsecurity.nu/toolbox/pmdump/) - only required if using SSF to get access to 68000 RAM
#	bin2psf (http://www.neillcorlett.com/psf/utilities.html) - PSF format converter
# -----------------------------------------------------------------------------------------------------
# To setup:
# 	Place this script, pmdump (if using SSF), and bin2psf in the same directory. It is recommended that 
#	a previously empty directory is used as this script will overwrite some files (ssf.bin, ssfdata.bin, 
#	ssfdata.ssf, history_buffer.txt)
# -----------------------------------------------------------------------------------------------------
# To run (general):
# 	The script runs off of user-selected parameters that initialize sound playback (all of which are 
#	changed within this script in the parameter section below). Picking the right values is absolutely 
#	necessary in getting correct playback. Most game drivers keep a history buffer of sound commands.
#	The script will dump relevant ones into the file history_buffer.txt when run. You can use the file to
#	help select the right script parameters (variable names are consistent between history_buffer.txt 
#	and this script). Since you can always run the script again with different parameters after the sound
#	memory is dumped, don't worry too much about parameter selection on the first run.
#
#	The history buffer contains the last 128 commands sent from the host system to the sound driver. In
#	most cases, the commands outputted to history_buffer.txt are ordered top to bottom from the earliest
#	to the most recent command, so begin with the bottom of the list and work your way upwards when 
#	looking for parameters to select.
#
# To run (SSF):
#      (1) Start game in SSF (emulator).
#	(2) When sequenced music is playing in SSF, run the script and an ssf file should be made (make sure
#		the variable pmdump is set to 1 for the first time the script is run). The ssf file will be called 
#		ssfdata.ssf. It is overwritten everytime this script is run, so it's a good idea to rename it right 
#		after you've successfully dumped something. You may not get the parameter selection right on 
#		your first run. If not, try running the script again with different values (use the
#		history_buffer.txt output to help out with parameter selection). For subsequent runs on 
#		the same sequence data, set the pmdump variable to 0 to speed up processing (no need to run 
#		again if you've already done it once).
#
# To run (Yabause):
#	(1) Start game in Yabause (emulator).
#	(2) When sequenced music is playing in Yabause, go to "File" --> "Memory Transfer". Select the 
#		"Download" button. For "File:", use the filename ssf.bin and put into the same directory as 
#		the script. Enter 05A00000 for the start address and 05A80000 for the end address. Hit 
#		"OK". This will produce a dump of 68000 RAM.
#	(3) Since Yabause can dump 68000 RAM, pmdump is not needed, so make sure the pmdump variable
#		in the script is set to 0. Run the script and an ssf file should be made. The ssf file will be 
#		called ssfdata.ssf. It is overwritten everytime this script is run, so it's a good idea to rename
#		it right after you've successfully dumped something. You may not get the parameter selection 
#		right on your first run. If not, try running the script again with different values (use the
#		history_buffer.txt output to help out with parameter selection).
#
# To run (other):
#   (1) Dump the sound RAM to a file named ssf.bin.
#   (2) Run script after setting parameters (set pmdump variable to 0). 
#
#	NOTE: If the ssf file isn't producing any sounds or is producing something other than what you want
#		(such as sound effects instead of music), try changing the bank and track variables below. First 
#		examine the history_buffer.txt (generated every time the script is run)  output for new values to 
#		try. You'll want to look for instances of the SEQUENCE_START command in particular. If nothing 
#		in there works or if the file is empty (some games might not keep a command history), you can 
#		always manually try different combinations. 
#
#   NOTE: When using the DSP, make sure a suitable mixer is selected. If the selected mixer contains 
#       zero values for the effect send levels, effects will not be applied. ssfinfo.py can be used to 
#       check mixer settings.
#
#	NOTE: In some cases where the output ssf file appears to not be generating any sound, it actually can 
# 		be, but at an extremely low volume (ex. EVE Burst Error, Soukyugurentai). Not sure if it's a player 
#		or script issue, but it can be remedied somewhat by setting the volume tag in the ssf file to an 
#       appropriate value (something very large like 64) if you don't mind a decreased signal-to-noise ratio.
# =====================================================================================================

# =====================================================================================================
# PARAMETERS - these are to be changed by the user each time the script is to be run
bank      =  0x00     # sequence bank number
track     =  0x00     # sequence song number
volume    =  0x7F     # reduce if clipping (0x7F is max)
use_dsp   =  1        # 1: yes, 0: no
effect    =  0x00     # DSP effect bank (usually 0)
mixerbank =  bank     # mixer bank number (usually same as sequence bank number)
mixern    =  0x00     # mixer number (usually 0)
pmdump    =  1        # 1: use pmdump, 0: use ssf.bin in script directory
# -----------------------------------------------------------------------------------------------------
# parameters for 68000 RAM search in pmdump output (these probably won't need to be changed often)
# Usually, a MOVE #0x2700,SR instruction ('\x46\xFC\x27\x00') is the first thing in the driver's reset 
# handler, so that's not a bad thing to search for.
sstring  = '\x46\xFC\x27\x00' # string to search for in sound data
pstring  = 0x1000     # location of sstring in 68000 RAM
origin   = 0x4200000  # offset to start looking for 68000 RAM in the pmdump output
endpoint = 0x4600000  # offset to stop looking for 68000 RAM in the pmdump output
# =====================================================================================================

# =====================================================================================================
from struct import *    # pack, unpack
from array import *    # array
import os    # system
import time    # sleep
# -----------------------------------------------------------------------------------------------------
# Converts list of bytes into a string object used by the write function
def bytes2str(x):
	return ''.join(map(lambda u: pack('B',u),x))
# -----------------------------------------------------------------------------------------------------
# Converts list of bytes into a sound command string (zero-padded out to 16 bytes)
def soundcmd(x):
	if len(x) > 0x10:
		x = x[:0x10]
	return bytes2str(x + [0x00]*(0x10-len(x)))
# -----------------------------------------------------------------------------------------------------
# pmdump the emulator process to get access to uncompressed 68000 RAM
# otherwise use ssf.bin in the script directory
if pmdump:
	os.system('del ssf.bin')
	os.system('pmdump -list | find /I "- SSF.exe" > pmdump.out') # find emulator PID
	fp = open('pmdump.out','r')
	pmdump_out = fp.readline();
	fp.close()
	time.sleep(0.5)
	os.system('pmdump '+pmdump_out.split()[0]+' ssf.bin')
	time.sleep(0.5)
# -----------------------------------------------------------------------------------------------------
fi = open('ssf.bin','rb')
fo = open('ssfdata.bin','wb')
# -----------------------------------------------------------------------------------------------------
# Search for 68000 RAM
fi.seek(0,2)
fisize = fi.tell()
if fisize > 0x100000:    # pmdump output
	fi.seek(origin)
	line = fi.read(endpoint-origin)
	offset = line.find(sstring)
	fi.seek(origin+offset-pstring)
else:    # 68000 RAM dump
	fi.seek(0)
# -----------------------------------------------------------------------------------------------------
# load address (always 0x00000000 for ssf)
load = pack('I',0x00000000)
fo.write(load)
# -----------------------------------------------------------------------------------------------------
# 0x00000 - 0x00480 : 68000 vector and system info tables
line = fi.read(0x480)
hptr = unpack('>H',line[0x41A:0x41C])[0] & 0x7F0    # current history buffer pointer
fo.write(line)
# -----------------------------------------------------------------------------------------------------
# 0x00480 - 0x004FF : zero fill
fo.write('\x00'*0x80)
fi.seek(0x80,1)
# -----------------------------------------------------------------------------------------------------
# 0x00500 - 0x005FF : area map
line = fi.read(0x100)
fo.write(line)
# -----------------------------------------------------------------------------------------------------
# 0x00600 - 0x006FF : zero fill
fo.write('\x00'*0x100)
fi.seek(0x100,1)
# -----------------------------------------------------------------------------------------------------
# 0x00700 - 0x0077F : sound driver commands
# First argument is command number, second argument is always 0x00, rest of the arguments are command parameters.
cmd0 = soundcmd([0x87,0x00,mixerbank,mixern])           # MIXER_CHANGE
cmd1 = soundcmd([0x83,0x00,effect])                    # EFFECT_CHANGE
cmd2 = soundcmd([0x01,0x00,0x00,bank,track,0x00])      # SEQUENCE_START
cmd3 = soundcmd([0x05,0x00,0x00,volume,0x00])          # SEQUENCE_VOLUME
cmd4 = soundcmd([])                                    # NULL_CMD
cmd5 = soundcmd([])                                    # NULL_CMD
cmd6 = soundcmd([])                                    # NULL_CMD
cmd7 = soundcmd([])                                    # NULL_CMD
cmds = (cmd0,cmd1,cmd2,cmd3,cmd4,cmd5,cmd6,cmd7)
for cmd in cmds:    # write out sound driver commands
	if cmd[0]=='\x83' and not use_dsp:
		fo.write(soundcmd([]))    # write NULL_CMD in place of EFFECT_CHANGE if use_dsp flag not set
	else:
		fo.write(cmd)
fi.seek(0x80,1)
# -----------------------------------------------------------------------------------------------------
# 0x00780 - 0x007BF : zero fill
fo.write('\x00'*0x40)
fi.seek(0x40,1)
# -----------------------------------------------------------------------------------------------------
# 0x007C0 - 0x007FF : reserved section (NiGHTS uses it)
line = fi.read(0x40)
fo.write(line)
# -----------------------------------------------------------------------------------------------------
# 0x00800 - 0x00FFF : history buffer
# process relevant SCSP commands in history buffer and write to text file
hbuffer = fi.read(0x800)
fo.write(hbuffer)
ncommand = 0x00
fh = open('history_buffer.txt','w')
while ncommand < 0x80:
	hblock = unpack('B'*16,hbuffer[hptr:hptr+0x10])
	fh.write('[0x%04X] ' % (hptr + 0x800))
	hptr += 0x10
	hptr &= 0x7F0
	if hblock[0] == 0x01:      # SEQUENCE_START
		fh.write('SEQUENCE_START (0x%02X): control=0x%02X bank=0x%02X track=0x%02X priority=0x%02X\n' % (hblock[:1]+hblock[2:6]))
	elif hblock[0] == 0x02:    # SEQUENCE_STOP
		fh.write('SEQUENCE_STOP (0x%02X): control=0x%02X\n' % (hblock[:1]+hblock[2:3]))
	elif hblock[0] == 0x03:    # SEQUENCE_PAUSE
		fh.write('SEQUENCE_PAUSE (0x%02X): control=0x%02X\n' % (hblock[:1]+hblock[2:3]))
	elif hblock[0] == 0x04:    # SEQUENCE_CONTIUNE
		fh.write('SEQUENCE_CONTINUE (0x%02X): control=0x%02X\n' % (hblock[:1]+hblock[2:3]))
	elif hblock[0] == 0x05:    # SEQUENCE_VOLUME
		fh.write('SEQUENCE_VOLUME (0x%02X): control=0x%02X volume=0x%02X fade=0x%02X\n' % (hblock[:1]+hblock[2:5]))
	elif hblock[0] == 0x07:    # TEMPO_CHANGE
		htempo = unpack('>h',bytes2str(hblock[4:6]))
		fh.write('TEMPO_CHANGE (0x%02X): control=0x%02X tempo=0x%04X\n' % (hblock[:1]+hblock[2:3]+htempo))
	elif hblock[0] == 0x08:    # MAP_CHANGE
		fh.write('MAP_CHANGE (0x%02X): map=0x%02X\n' % (hblock[:1]+hblock[2:3]))
	elif hblock[0] == 0x09:    # MIDI_DIRECT_CONTROL
		fh.write('MIDI_DIRECT_CONTROL (0x%02X): midi_cmd=0x%02X midi_chan=0x%02X midi_data1=0x%02X midi_data2=0x%02X\n' % (hblock[:1]+hblock[2:6])) 
	elif hblock[0] == 0x0A:    # VOLUME_ANALYZE_START
		fh.write('VOLUME_ANALYZE_START (0x%02X):\n' % (hblock[:1]))
	elif hblock[0] == 0x0B:    # VOLUME_ANALYZE_STOP
		fh.write('VOLUME_ANALYZE_STOP (0x%02X):\n' % (hblock[:1]))
	elif hblock[0] == 0x0C:    # DSP_STOP
		fh.write('DSP_STOP (0x%02X):\n' % (hblock[:1]))
	elif hblock[0] == 0x0D:    # SOUND_ALL_OFF
		fh.write('SOUND_ALL_OFF (0x%02X):\n' % (hblock[:1]))
	elif hblock[0] == 0x0E:    # SEQUENCE_PAN
		fh.write('SEQUENCE_PAN (0x%02X): control=0x%02X midi_pan=0x%02X\n' % (hblock[:1]+hblock[2:4]))
	elif hblock[0] == 0x10:    # SOUND_INITIAL
		fh.write('SOUND_INITIAL (0x%02X): stop_seq=0x%02X stop_pcm=0x%02X stop_cdda=0x%02X init_dsp=0x%02X init_mixer=0x%02X\n' % (hblock[:1]+hblock[2:7]))
	elif hblock[0] == 0x11:    # 3D_CONTROL
		fh.write('3D_CONTROL (0x%02X): channel=0x%02X distance=0x%02X hpos=0x%02X vpos=0x%02X\n' % (hblock[:1]+hblock[2:6]))
	elif hblock[0] == 0x12:    # QSOUND_CONTROL
		fh.write('QSOUND_CONTROL (0x%02X): channel=0x%02X panpos=0x%02X\n' % (hblock[:1]+hblock[2:4]))
	elif hblock[0] == 0x80:    # CDDA_LEVEL
		fh.write('CDDA_LEVEL (0x%02X): cdda_lvl_l=0x%02X cdda_lvl_r=0x%02x\n' % (hblock[:1]+hblock[2:4]))
	elif hblock[0] == 0x81:    # CDDA_PAN
		fh.write('CDDA_PAN (0x%02X): cdda_pan_l=0x%02X cdda_pan_r=0x%02X\n' % (hblock[:1]+hblock[2:4]))
	elif hblock[0] == 0x82:    # TOTAL_VOLUME
		fh.write('TOTAL_VOLUME (0x%02X): total_vol=0x%02X\n' % (hblock[:1]+hblock[2:3]))
	elif hblock[0] == 0x83:    # EFFECT_CHANGE
		fh.write('EFFECT_CHANGE (0x%02X): effect=0x%02X\n' % (hblock[:1]+hblock[2:3]))
	elif hblock[0] == 0x85:    # PCM_START
		hstereo = hblock[2] >> 7
		h8bit = (hblock[2] >> 4) & 0x1
		hstream = hblock[2] & 0xF
		hlevel = hblock[3] >> 5
		hpan = hblock[3] & 0x1F
		horigin = unpack('>H',bytes2str(hblock[4:6]))
		hsize = unpack('>H',bytes2str(hblock[6:8]))
		hpitch = unpack('>H',bytes2str(hblock[8:10]))
		hchanr = hblock[10] >> 3
		hpanr = hblock[10] & 0x7
		hchanl = hblock[11] >> 3
		hpanl = hblock[11] & 0x7
		fh.write('PCM_START (0x%02X): pcm_stereo=0x%02X pcm_8bit=0x%02X pcm_stream=0x%02X pcm_lvl=0x%02X pcm_pan=0x%02X pcm_origin=0x%02X pcm_size=0x%02X pcm_pitch=0x%02X pcm_fx_chan_r=0x%02X pcm_fx_lvl_r=0x%02X pcm_fx_chan_l=0x%02X pcm_fx_lvl_l=0x%02X\n' % (hblock[:1]+(hstereo,h8bit,hstream,hlevel,hpan)+horigin+hsize+hpitch+(hchanr,hpanr,hchanl,hpanl)))
	elif hblock[0] == 0x86:    # PCM_STOP
		fh.write('PCM_STOP (0x%02X): pcm_stream=0x%02X\n' % (hblock[:1]+hblock[2:3]))
	elif hblock[0] == 0x87:    # MIXER_CHANGE
		fh.write('MIXER_CHANGE (0x%02X): mixerbank=0x%02X mixern=0x%02x\n' % (hblock[:1]+hblock[2:4]))
	elif hblock[0] == 0x88:    # MIXER_PARAMETER_CHANGE
		heffect_lvl = hblock[3] >> 5
		heffect_pan = hblock[3] & 0x1F
		fh.write('MIXER_PARAMETER_CHANGE (0x%02X): effect_out=0x%02X effect_lvl=0x%02X effect_pan=0x%02x\n' % (hblock[:1]+hblock[2:3]+(heffect_lvl,heffect_pan)))
	elif hblock[0] == 0x89:    # HARD_CHECK
		fh.write('HARD_CHECK (0x%02X): check_item=0x%02X\n' % (hblock[:1]+hblock[2:3]))
	elif hblock[0] == 0x8A:    # PCM_PARAMETER_CHANGE
		hlevel = hblock[3] >> 5
		hpan = hblock[3] & 0x1F
		hpitch = unpack('>H',bytes2str(hblock[4:6]))
		hchanr = hblock[6] >> 3
		hpanr = hblock[6] & 0x7
		hchanl = hblock[7] >> 3
		hpanl = hblock[7] & 0x7
		fh.write('PCM_PARAMETER_CHANGE (0x%02X): pcm_stream=0x%02X pcm_lvl=0x%02X pcm_pan=0x%02X pcm_pitch=0x%02X pcm_fx_chan_r=0x%02X pcm_fx_lvl_r=0x%02X pcm_fx_chan_l=0x%02X pcm_fx_lvl_l=0x%02X\n' %  (hblock[:1]+hblock[2:3]+(hlevel,hpan)+hpitch+(hchanr,hpanr,hchanl,hpanl)))
	elif hblock[0] > 0 and hblock[0] < 0xFF:
		fh.write('___UNKNOWN_COMMAND (0x%02X): P1=0x%02X P2=0x%02X P3=0x%02X P4=0x%02X P5=0x%02X P6=0x%02X P7=0x%02X P8=0x%02X P9=0x%02X P10=0x%02X P11=0x%02X P12=0x%02X\n' % (hblock[:1]+hblock[2:14]))
	else:
		fh.write('\n')
	ncommand += 1
fh.close()
# -----------------------------------------------------------------------------------------------------
# 0x01000 - 0x07FFFF : sound driver + data
line = fi.read(0x7F000)
fo.write(line)
# -----------------------------------------------------------------------------------------------------
fi.close()
fo.close()
# -----------------------------------------------------------------------------------------------------
# Zero out DSP work RAM - earlier version of the sound driver fail to do this
fi = open('ssfdata.bin', 'rb')
load = fi.read(4)
ssfdata = array('B', fi.read())
fi.close()
offset = 0x500
while offset < 0x600:
	mode = ssfdata[offset] >> 4
	if mode == 3:
		address = unpack('>I', ssfdata[offset:offset+4])[0] & 0x00FFFFFF
		size = unpack('>I', ssfdata[offset+4:offset+8])[0] & 0x00FFFFFF
		ssfdata[address:address+size] = array('B', [0x60,0x00])*(size/2)
	offset += 8
fo = open('ssfdata.bin', 'wb')
fo.write(load)
fo.write(ssfdata)
fo.close()
# -----------------------------------------------------------------------------------------------------
# Create the ssf file
os.system('bin2psf ssf 17 ssfdata.bin')
# =====================================================================================================

# =====================================================================================================
# Update history:
# 08-05-28 (0.07) - Changed script to explicitly zero-out DSP work RAM, since older version of the
#   SDDRVS driver fail to do this. This will remove pops at the beginning of tracks.
# 07-11-13 (0.06) - Changed script so that the "reserved" section of the Host Interface Status Area 
#   (0x7C0-0x7FF) is no longer zero-filled. Some games actually use this section for something useful
#   (NiGHTS).
# 07-09-22 (0.05) - Changed history buffer output so that it starts from the earliest command sent and 
#	ends with the most recent one. Also changed the history buffer output to list all sound driver commands
#	(that I know of) instead of only those that the script is set up to change. Cleaned up the sound command 
#	code a bit to make it a bit easier to send different commands than the script default (if necessary).
# 07-09-16 (0.04) - Adapted the script to support both SSF and Yabause. There are no changes from before 
#	in how the script is run using SSF. I separated the sequence and tone banks into two separate variables 
#	(although I would expect them to be the same in most cases). Changed the 68000 RAM search into 
#	something sensible. What I had originally was just plain stupid and sloppy.
# 07-09-16 (0.03) - Added a history buffer output, dumping relevant SCSP commands to a text file.
#	Use this to help select the correct script parameters.
# 07-09-15 (0.02) - Minor memory address fixes. Added an option to avoid going through pmdump (useful
#	for changing bank numbers, track numbers, etc.). Added comments and partitioned the script to 
#	improve readability.
# 07-09-15 (0.01) - Fixed the script so that it takes 0x400-0x47F from 68000 RAM instead of
#	overwritng with zeros. Same with 0x800-0xFFF. The driver seems to keep a history buffer
#	of SCSP commands in the 0x800 region - might be able to leverage this to automate parameter
#	selection somewhat. Changed search string to something more reasonable.
# 07-09-14 (0.00) - initial version
# =====================================================================================================